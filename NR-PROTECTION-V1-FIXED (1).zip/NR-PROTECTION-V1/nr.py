#!/usr/bin/env python3
"""
NR Protection - VPS DDoS Protection & Operations Tool
Copyright (c) 2024 NR Protection. All Rights Reserved.
LICENSE KEY: madebynissalop2tnxforuse

FIXED:
- Never blocks 127.0.0.1 / localhost / private IPs
- When IP is blocked, existing connections are killed (load removed)
- Settings (toggles) now save correctly when turned OFF
- Panel remains open and usable from local machine
"""

import os, json, time, threading, logging, ipaddress
from datetime import datetime, timezone
from functools import wraps
from collections import defaultdict

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import psutil, socket, requests, subprocess

# ==================== LOGGING ====================
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%H:%M:%S')
logger = logging.getLogger('NRProtection')
logging.getLogger('werkzeug').setLevel(logging.ERROR)

# ==================== LICENSE ====================
LICENSE_KEY = "madebynissalop2tnxforuse"
LICENSE_FILE = 'nr_license.lic'

def check_license():
    if os.path.exists(LICENSE_FILE):
        with open(LICENSE_FILE, 'r') as f: return f.read().strip() == LICENSE_KEY
    return False

def verify_license_key(key):
    if key == LICENSE_KEY:
        with open(LICENSE_FILE, 'w') as f: f.write(LICENSE_KEY)
        return True
    return False

# ==================== APP CONFIG ====================
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24).hex()
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///nr.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# SQLite-friendly engine options (pool_size not supported the same way on SQLite)
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'pool_pre_ping': True}

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

ADVANCED_ADMIN_PASS = None
SETTINGS_FILE = 'nr_settings.json'
ddos_tracker = defaultdict(list)
blocked_ips = set()
settings_cache = {}
settings_cache_time = 0
block_logged = set()

# ==================== LOCAL / PRIVATE IP HELPERS ====================

# Cached own public IP (refreshed periodically)
_own_public_ip = None
_own_public_ip_ts = 0

def get_own_public_ip():
    """VPS public IP – never block this either."""
    global _own_public_ip, _own_public_ip_ts
    now = time.time()
    if _own_public_ip and (now - _own_public_ip_ts) < 300:
        return _own_public_ip
    try:
        _own_public_ip = requests.get('https://api.ipify.org?format=json', timeout=3).json().get('ip')
        _own_public_ip_ts = now
    except Exception:
        try:
            _own_public_ip = socket.gethostbyname(socket.gethostname())
            _own_public_ip_ts = now
        except Exception:
            _own_public_ip = None
    return _own_public_ip


def is_protected_ip(ip_str):
    """
    Return True if IP must NEVER be blocked:
    - localhost (127.0.0.0/8, ::1)
    - private ranges (10/8, 172.16/12, 192.168/16)
    - link-local (169.254/16, fe80::/10)
    - our own public VPS IP
    - unspecified / invalid
    """
    if not ip_str or ip_str in ('*', '-', '::', '0.0.0.0'):
        return True
    cleaned = ip_str.strip('[]')
    if cleaned.startswith(':'):
        return True
    # Own public IP
    own = get_own_public_ip()
    if own and cleaned == own:
        return True
    try:
        addr = ipaddress.ip_address(cleaned)
        return (
            addr.is_loopback
            or addr.is_private
            or addr.is_link_local
            or addr.is_unspecified
            or addr.is_reserved
        )
    except ValueError:
        return True


# Backwards-compatible alias
def is_local_or_private_ip(ip_str):
    return is_protected_ip(ip_str)


def normalize_ip(ip_str):
    """Normalize IP string from ss/netstat output."""
    if not ip_str:
        return None
    s = ip_str.strip().strip('[]')
    if s in ('*', '-', '::', '0.0.0.0'):
        return None
    return s


# ==================== MODELS ====================

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_advanced_admin = db.Column(db.Boolean, default=False)
    is_blocked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    last_login = db.Column(db.DateTime)
    ip_address = db.Column(db.String(45))
    def set_password(self, pw): self.password_hash = generate_password_hash(pw)
    def check_password(self, pw): return check_password_hash(self.password_hash, pw)

class BlockedIP(db.Model):
    __tablename__ = 'blocked_ip'
    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(45), nullable=False)
    reason = db.Column(db.String(200))
    blocked_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    blocked_by = db.Column(db.String(80))
    is_active = db.Column(db.Boolean, default=True)

class DDoSAttempt(db.Model):
    __tablename__ = 'ddos_attempt'
    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(45), nullable=False)
    target_port = db.Column(db.Integer)
    request_count = db.Column(db.Integer)
    detected_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    mitigated = db.Column(db.Boolean, default=False)
    attack_type = db.Column(db.String(50))

class VPSAction(db.Model):
    __tablename__ = 'vps_action'
    id = db.Column(db.Integer, primary_key=True)
    action_type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='pending')
    progress = db.Column(db.Integer, default=0)
    message = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    performed_by = db.Column(db.String(80))
    details = db.Column(db.Text)

class PanelSettings(db.Model):
    __tablename__ = 'panel_settings'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.String(500), nullable=False)

# ==================== HELPERS ====================

def init_db():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        a = User(username='admin', email='admin@localhost.com', is_admin=True); a.set_password('admin'); db.session.add(a)
    for k, v in {'auto_protection':'on','enable_registration':'on','maintenance_mode':'off','background':'snow','panel_name':'NR Protection','auto_block':'on','ddos_threshold':'50'}.items():
        if not PanelSettings.query.filter_by(key=k).first(): db.session.add(PanelSettings(key=k, value=v))
    db.session.commit()
    for ip in BlockedIP.query.filter_by(is_active=True).all():
        if not is_protected_ip(ip.ip_address):
            blocked_ips.add(ip.ip_address)
        else:
            # Clean any previously wrongly blocked local IPs
            ip.is_active = False
            db.session.commit()
            logger.warning(f"Cleaned invalid local block: {ip.ip_address}")

def get_setting_cached(key, default=''):
    global settings_cache, settings_cache_time
    now = time.time()
    if now - settings_cache_time > 5:
        try: settings_cache = {s.key: s.value for s in PanelSettings.query.all()}; settings_cache_time = now
        except: pass
    return settings_cache.get(key, default)

def get_setting(key, default=''):
    s = PanelSettings.query.filter_by(key=key).first(); return s.value if s else default

def set_setting(key, value):
    s = PanelSettings.query.filter_by(key=key).first()
    if s: s.value = str(value)
    else: db.session.add(PanelSettings(key=key, value=str(value)))
    db.session.commit(); global settings_cache_time; settings_cache_time = 0

def get_stats():
    try:
        m = psutil.virtual_memory(); d = psutil.disk_usage('/'); c = psutil.cpu_percent(interval=0.3)
        return {'cpu':c,'mem':m.percent,'disk':d.percent,'cpu_percent':c,'memory_percent':m.percent,'disk_percent':d.percent,'memory_used':f"{m.used/(1024**3):.1f}",'memory_total':f"{m.total/(1024**3):.1f}",'disk_used':f"{d.used/(1024**3):.1f}",'disk_total':f"{d.total/(1024**3):.1f}",'cpu_count':psutil.cpu_count()}
    except: return {'cpu':0,'mem':0,'disk':0,'cpu_percent':0,'memory_percent':0,'disk_percent':0,'memory_used':'0','memory_total':'0','disk_used':'0','disk_total':'0','cpu_count':0}

def get_vps_ip():
    try: return requests.get('https://api.ipify.org?format=json', timeout=3).json()['ip']
    except:
        try: return socket.gethostbyname(socket.gethostname())
        except: return '127.0.0.1'

def check_port(h, p):
    try: s = socket.socket(socket.AF_INET, socket.SOCK_STREAM); s.settimeout(2); r = s.connect_ex((h,p)); s.close(); return r==0
    except: return False

def detect_service(port=80):
    try:
        r = subprocess.run(['lsof','-i',f':{port}','-sTCP:LISTEN','-t'], capture_output=True, text=True, timeout=3)
        if r.stdout.strip():
            ps = subprocess.run(['ps','-p',r.stdout.strip().split('\n')[0],'-o','comm='], capture_output=True, text=True, timeout=3)
            if ps.stdout.strip(): return ps.stdout.strip()
        for s in ['nginx','apache2','httpd','caddy','node','python']:
            if subprocess.run(['pgrep',s], capture_output=True).returncode==0: return {'httpd':'Apache','apache2':'Apache','node':'Node.js','python':'Python'}.get(s,s.capitalize())
        return 'Unknown'
    except: return 'Unknown'

def kill_connections_for_ip(ip):
    """
    Aggressively delete ALL existing connections involving this IP.
    Goal: the ~49 (or N) requests already received stop being processed
    so they cannot slow the VPS after the block.
    """
    # --- 1) Force TCP RST on active sockets (fastest way to free server resources) ---
    try:
        subprocess.run(
            ['iptables', '-I', 'INPUT', '1', '-s', ip, '-p', 'tcp',
             '-j', 'REJECT', '--reject-with', 'tcp-reset'],
            capture_output=True, timeout=5
        )
        subprocess.run(
            ['iptables', '-I', 'OUTPUT', '1', '-d', ip, '-p', 'tcp',
             '-j', 'REJECT', '--reject-with', 'tcp-reset'],
            capture_output=True, timeout=5
        )
    except Exception:
        pass

    # --- 2) ss -K: kill sockets by filter (multiple syntaxes for different kernels) ---
    ss_cmds = [
        ['ss', '-K', 'dst', ip],
        ['ss', '-K', 'src', ip],
        ['ss', '-K', 'dst', f'{ip}'],
        ['ss', '-K', 'src', f'{ip}'],
        ['ss', '-K', 'dport', '=', '0'],  # noop safety; real kills below
    ]
    for cmd in ss_cmds[:4]:
        try:
            subprocess.run(cmd, capture_output=True, timeout=5)
        except Exception:
            pass

    # Also kill by matching any line that contains the IP (state all)
    try:
        # List and kill established / syn-recv / fin-wait etc.
        for state in ('established', 'syn-recv', 'fin-wait-1', 'fin-wait-2',
                      'time-wait', 'close-wait', 'last-ack', 'syn-sent'):
            try:
                subprocess.run(
                    ['ss', '-K', 'state', state, 'dst', ip],
                    capture_output=True, timeout=3
                )
                subprocess.run(
                    ['ss', '-K', 'state', state, 'src', ip],
                    capture_output=True, timeout=3
                )
            except Exception:
                pass
    except Exception:
        pass

    # --- 3) conntrack: wipe kernel connection tracking entries ---
    for args in (
        ['conntrack', '-D', '-s', ip],
        ['conntrack', '-D', '-d', ip],
        ['conntrack', '-D', '-s', ip, '-p', 'tcp'],
        ['conntrack', '-D', '-d', ip, '-p', 'tcp'],
        ['conntrack', '-D', '-s', ip, '-p', 'udp'],
        ['conntrack', '-D', '-d', ip, '-p', 'udp'],
    ):
        try:
            subprocess.run(args, capture_output=True, timeout=3)
        except Exception:
            pass

    # --- 4) tcpkill / killcx if installed (extra tools) ---
    for tool_cmd in (
        ['tcpkill', '-i', 'any', 'host', ip],
        ['killcx', f'{ip}:0'],
    ):
        try:
            # short timeout – these are long-running if left alone
            subprocess.run(tool_cmd, capture_output=True, timeout=2)
        except Exception:
            pass

    # --- 5) Second pass of ss -K after RST (catch stragglers) ---
    for direction in ('dst', 'src'):
        try:
            subprocess.run(['ss', '-K', direction, ip], capture_output=True, timeout=3)
        except Exception:
            pass

    # --- 6) Remove temporary REJECT rules (permanent DROP is added by block_ip) ---
    for rule in (
        ['iptables', '-D', 'INPUT', '-s', ip, '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset'],
        ['iptables', '-D', 'OUTPUT', '-d', ip, '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset'],
    ):
        try:
            subprocess.run(rule, capture_output=True, timeout=3)
        except Exception:
            pass


def block_ip(ip, reason, by):
    """
    BLOCK IP IMMEDIATELY.
    - Never blocks local / private / own public IP
    - Kills ALL existing connections FIRST so already-received requests
      are deleted and stop loading the VPS
    - Then firewall DROP so new packets never arrive
    """
    if not ip or is_protected_ip(ip):
        logger.warning(f"Refused to block protected IP (local/own): {ip}")
        return False
    if ip in blocked_ips:
        # Already blocked – still force-kill any remaining connections
        kill_connections_for_ip(ip)
        return False

    # In-memory block first (panel checks this instantly)
    blocked_ips.add(ip)

    # Clear rate-tracker for this IP
    try:
        ddos_tracker.pop(ip, None)
    except Exception:
        pass

    # 1) KILL existing connections FIRST (the 49 in-flight requests stop here)
    kill_connections_for_ip(ip)

    # 2) Permanent firewall DROP – new packets never processed
    try:
        # Insert at top of chain so it wins over other rules
        subprocess.run(
            ['iptables', '-I', 'INPUT', '1', '-s', ip, '-j', 'DROP'],
            capture_output=True, timeout=5
        )
        subprocess.run(
            ['iptables', '-I', 'OUTPUT', '1', '-d', ip, '-j', 'DROP'],
            capture_output=True, timeout=5
        )
        # Also FORWARD in case of routed traffic
        subprocess.run(
            ['iptables', '-I', 'FORWARD', '1', '-s', ip, '-j', 'DROP'],
            capture_output=True, timeout=5
        )
        subprocess.run(
            ['iptables', '-I', 'FORWARD', '1', '-d', ip, '-j', 'DROP'],
            capture_output=True, timeout=5
        )
    except Exception:
        pass

    # 3) Kill again after DROP (any race-window connections)
    kill_connections_for_ip(ip)

    # 4) DB record (non-blocking for protection path)
    try:
        if not BlockedIP.query.filter_by(ip_address=ip, is_active=True).first():
            db.session.add(BlockedIP(ip_address=ip, reason=reason, blocked_by=by))
            db.session.commit()
    except Exception:
        try:
            db.session.rollback()
        except Exception:
            pass

    if ip not in block_logged:
        block_logged.add(ip)
        logger.warning(f"BLOCKED + ALL connections deleted: {ip} - {reason}")
    return True

def unblock_ip(ip):
    blocked_ips.discard(ip)
    block_logged.discard(ip)
    for rule in (
        ['iptables', '-D', 'INPUT', '-s', ip, '-j', 'DROP'],
        ['iptables', '-D', 'OUTPUT', '-d', ip, '-j', 'DROP'],
        ['iptables', '-D', 'FORWARD', '-s', ip, '-j', 'DROP'],
        ['iptables', '-D', 'FORWARD', '-d', ip, '-j', 'DROP'],
        ['iptables', '-D', 'INPUT', '-s', ip, '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset'],
        ['iptables', '-D', 'OUTPUT', '-d', ip, '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset'],
    ):
        try:
            # May exist multiple times – try a few removals
            for _ in range(3):
                subprocess.run(rule, capture_output=True, timeout=3)
        except Exception:
            pass
    b = BlockedIP.query.filter_by(ip_address=ip, is_active=True).first()
    if b:
        b.is_active = False
        db.session.commit()
        return True
    return False

# ==================== PANEL DDoS DETECTION (Port 3500) ====================

def detect_ddos_panel(ip, port=None):
    """Detect DDoS on panel routes – never tracks/blocks own/local IPs."""
    if is_protected_ip(ip):
        return False, 0
    now = time.time()
    ddos_tracker[ip].append(now)
    ddos_tracker[ip] = [t for t in ddos_tracker[ip] if now - t < 60]
    c = len(ddos_tracker[ip])
    threshold = int(get_setting_cached('ddos_threshold', '50'))
    if c >= threshold:
        with app.app_context():
            a = DDoSAttempt(ip_address=ip, target_port=port or 3500, request_count=c, attack_type='Panel DDoS')
            db.session.add(a)
            if get_setting_cached('auto_block', 'on') == 'on':
                block_ip(ip, f'Auto: Panel DDoS ({c}/min)', 'SYSTEM')
                a.mitigated = True
            db.session.commit()
        return True, c
    return False, c

# ==================== ALL-PORT MONITOR ====================

def monitor_all_ports():
    """
    Monitor ALL TCP connections on ALL ports.
    Blocks public IPs when connection count >= threshold.
    NEVER blocks localhost / private / link-local IPs.
    On block: kills existing connections so load is cleared.
    """
    logger.info("ALL-PORT MONITOR ACTIVE - own/local IPs never blocked; others silent-dropped")
    time.sleep(3)
    while True:
        try:
            result = subprocess.run(['ss', '-tan'], capture_output=True, text=True, timeout=5)
            ip_counts = defaultdict(int)
            for line in result.stdout.split('\n'):
                parts = line.split()
                if len(parts) >= 5:
                    remote = parts[4] if len(parts) > 4 else ""
                    if ':' in remote:
                        # Handle IPv6 [::1]:port and IPv4 1.2.3.4:port
                        if remote.startswith('['):
                            # [addr]:port
                            end = remote.rfind(']')
                            ip = remote[1:end] if end > 0 else remote
                        else:
                            ip = remote.rsplit(':', 1)[0]
                        ip = normalize_ip(ip)
                        if ip and not is_protected_ip(ip):
                            ip_counts[ip] += 1

            threshold = int(get_setting_cached('ddos_threshold', '50'))

            for ip, count in ip_counts.items():
                if count >= threshold and ip not in blocked_ips:
                    logger.warning(f"DDoS DETECTED: {ip} - {count} connections - BLOCKING + killing connections")
                    with app.app_context():
                        try:
                            a = DDoSAttempt(
                                ip_address=ip, target_port=0, request_count=count,
                                attack_type='All-Port Attack', mitigated=True
                            )
                            db.session.add(a)
                            db.session.commit()
                        except Exception:
                            try:
                                db.session.rollback()
                            except Exception:
                                pass
                    block_ip(ip, f'Auto: {count} connections - BLOCKED', 'SYSTEM')

            time.sleep(1)
        except Exception:
            time.sleep(3)

# ==================== VPS ACTIONS ====================

def execute_reboot():
    for cmd in [['reboot'], ['shutdown', '-r', 'now']]:
        try:
            if subprocess.run(cmd, capture_output=True, text=True, timeout=10).returncode == 0:
                return True, "Reboot executed!"
        except Exception:
            continue
    return False, "Reboot failed"

def execute_shutdown():
    for cmd in [['shutdown', '-h', 'now'], ['poweroff'], ['halt']]:
        try:
            if subprocess.run(cmd, capture_output=True, text=True, timeout=10).returncode == 0:
                return True, "Shutdown executed!"
        except Exception:
            continue
    return False, "Shutdown failed"

def execute_stop_port(port):
    try:
        r1 = subprocess.run(['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', str(port), '-j', 'DROP'], capture_output=True, text=True, timeout=10)
        r2 = subprocess.run(['iptables', '-A', 'INPUT', '-p', 'udp', '--dport', str(port), '-j', 'DROP'], capture_output=True, text=True, timeout=10)
        if r1.returncode == 0 and r2.returncode == 0:
            return True, f"Port {port} blocked"
        return False, "Permission denied"
    except Exception:
        return False, "iptables not found"

def execute_port_forward(sp, dp):
    try:
        subprocess.run(['sysctl', '-w', 'net.ipv4.ip_forward=1'], capture_output=True, timeout=10)
        r1 = subprocess.run(['iptables', '-t', 'nat', '-A', 'PREROUTING', '-p', 'tcp', '--dport', str(sp), '-j', 'REDIRECT', '--to-port', str(dp)], capture_output=True, text=True, timeout=10)
        r2 = subprocess.run(['iptables', '-t', 'nat', '-A', 'PREROUTING', '-p', 'udp', '--dport', str(sp), '-j', 'REDIRECT', '--to-port', str(dp)], capture_output=True, text=True, timeout=10)
        if r1.returncode == 0 and r2.returncode == 0:
            return True, f"Forward {sp}->{dp} active"
        return False, "Permission denied"
    except Exception:
        return False, "iptables not found"

def vps_action(act, det=None):
    un = current_user.username if current_user.is_authenticated else 'SYSTEM'
    a = VPSAction(action_type=act, performed_by=un, details=json.dumps(det) if det else None)
    db.session.add(a); db.session.commit(); aid = a.id
    def run():
        with app.app_context():
            ac = db.session.get(VPSAction, aid)
            if not ac:
                return
            steps = {
                'reboot': [(10, 'Preparing...'), (30, 'Stopping...'), (50, 'Syncing...'), (70, 'Rebooting...'), (85, 'Executing...'), (95, 'Checking...')],
                'stop_vps': [(15, 'Preparing...'), (35, 'Stopping...'), (55, 'Closing...'), (75, 'Saving...'), (85, 'Executing...'), (95, 'Checking...')],
                'stop_port': [(20, f'Port {det.get("port", "")}...'), (40, 'Blocking TCP...'), (60, 'Blocking UDP...'), (80, 'Applying...'), (95, 'Verifying...')],
                'port_forward': [(15, 'Enabling...'), (35, f'{det.get("source_port", "")}->{det.get("dest_port", "")}...'), (55, 'TCP rule...'), (70, 'UDP rule...'), (85, 'Allowing...'), (95, 'Verifying...')]
            }
            for p, m in steps.get(act, [(50, 'Processing...'), (100, 'Done')]):
                time.sleep(0.5)
                ac.progress = p
                ac.message = m
                db.session.commit()
            success, msg = False, ""
            if act == 'reboot':
                success, msg = execute_reboot()
            elif act == 'stop_vps':
                success, msg = execute_shutdown()
            elif act == 'stop_port' and det:
                success, msg = execute_stop_port(det.get('port'))
            elif act == 'port_forward' and det:
                success, msg = execute_port_forward(det.get('source_port'), det.get('dest_port'))
            else:
                msg = "Unknown action"
            ac.progress = 100
            ac.message = f"{'SUCCESS' if success else 'FAILED'}: {msg}"
            ac.status = 'completed' if success else 'failed'
            db.session.commit()
    threading.Thread(target=run, daemon=True).start()
    return aid

# ==================== DECORATORS ====================

def admin_req(f):
    @wraps(f)
    def d(*a, **k):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin required', 'danger')
            return redirect(url_for('dashboard'))
        return f(*a, **k)
    return d

def adv_req(f):
    @wraps(f)
    def d(*a, **k):
        if not current_user.is_authenticated or not current_user.is_advanced_admin:
            flash('Advanced admin required', 'danger')
            return redirect(url_for('dashboard'))
        return f(*a, **k)
    return d

@login_manager.user_loader
def load_user(uid):
    return db.session.get(User, int(uid))

@app.context_processor
def inject_vars():
    return {'panel_name': get_setting_cached('panel_name', 'NR Protection'), 'vps_ip': get_vps_ip()}

# ==================== BEFORE REQUEST (IMMEDIATE BLOCK) ====================

@app.before_request
def immediate_block_check():
    """
    FIRST: Silently drop requests from blocked IPs.
    No JSON, no page – empty body so it looks like nothing happened.
    Our own / local IPs are never in blocked_ips.
    """
    ip = request.remote_addr
    if ip and ip in blocked_ips and not is_protected_ip(ip):
        # Empty response, connection closes – attacker sees no useful reply
        return '', 403

@app.before_request
def ddos_detection_check():
    """SECOND: Detect DDoS on panel routes (skips our/local IPs)."""
    if request.endpoint and request.endpoint not in ['static', 'license_page', 'verify_license']:
        ip = request.remote_addr
        if is_protected_ip(ip) or ip in blocked_ips:
            return None
        is_attack, count = detect_ddos_panel(ip)
        if is_attack:
            # Already blocked + connections killed – silent empty response
            return '', 429

@app.before_request
def maintenance_mode_check():
    if get_setting_cached('maintenance_mode') == 'on':
        if request.endpoint not in ['login', 'logout', 'static', 'index', 'license_page', 'verify_license']:
            if not current_user.is_authenticated or not current_user.is_admin:
                return render_template('maintenance.html')

@app.before_request
def license_verification_check():
    if request.endpoint in ['license_page', 'verify_license', 'static']:
        return None
    if check_license():
        return None
    if request.endpoint != 'license_page':
        return redirect(url_for('license_page'))

# ==================== ROUTES ====================

@app.route('/license', methods=['GET', 'POST'])
def license_page():
    if check_license():
        return redirect(url_for('index'))
    if request.method == 'POST':
        if verify_license_key(request.form.get('license_key', '').strip()):
            flash('License verified!', 'success')
            return redirect(url_for('index'))
        flash('Invalid key!', 'danger')
    return render_template('license.html')

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html', features=[
        {'icon': 'fa-shield', 'title': 'DDoS Protection', 'description': 'Detects & BLOCKS attacks on EVERY port instantly'},
        {'icon': 'fa-server', 'title': 'VPS Control', 'description': 'Real reboot, shutdown, port control'},
        {'icon': 'fa-chart-line', 'title': 'Live Monitoring', 'description': 'CPU, RAM, Disk stats'},
        {'icon': 'fa-lock', 'title': 'IP Security', 'description': 'Block/unblock IPs - protects entire VPS'},
        {'icon': 'fa-bolt', 'title': 'Auto-Protection', 'description': 'Automatic threat mitigation on any port'},
        {'icon': 'fa-users', 'title': 'User Management', 'description': 'Full user administration'}
    ])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        user = User.query.filter(
            (User.username == request.form.get('username', '').strip()) |
            (User.email == request.form.get('username', '').strip())
        ).first()
        if user and user.check_password(request.form.get('password', '')):
            if user.is_blocked:
                flash('Account blocked', 'danger')
                return render_template('login.html')
            user.is_advanced_admin = False
            login_user(user)
            user.last_login = datetime.now(timezone.utc)
            user.ip_address = request.remote_addr
            db.session.commit()
            flash(f'Welcome {user.username}!', 'success')
            if user.is_admin:
                return redirect(url_for('dashboard_admin'))
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if get_setting_cached('enable_registration') != 'on':
        flash('Registration disabled', 'warning')
        return redirect(url_for('login'))
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        e = request.form.get('email', '').strip()
        p = request.form.get('password', '')
        c = request.form.get('confirm_password', '')
        if not all([u, e, p, c]):
            flash('All fields required', 'danger')
        elif p != c:
            flash('Passwords mismatch', 'danger')
        elif len(p) < 6:
            flash('Password too short', 'danger')
        elif User.query.filter_by(username=u).first():
            flash('Username taken', 'danger')
        elif User.query.filter_by(email=e).first():
            flash('Email taken', 'danger')
        else:
            user = User(username=u, email=e)
            user.set_password(p)
            db.session.add(user)
            db.session.commit()
            flash('Account created!', 'success')
            return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_advanced_admin:
        return redirect(url_for('dashboard_advanced'))
    if current_user.is_admin:
        return redirect(url_for('dashboard_admin'))
    pts = check_port('localhost', 80)
    port_status = {'online': False, 'service': 'Unknown'}
    if pts:
        port_status = {'online': True, 'service': detect_service(80)}
    return render_template(
        'dashboard_user.html',
        blocked_ips=BlockedIP.query.filter_by(is_active=True).all(),
        ddos_attempts=DDoSAttempt.query.order_by(DDoSAttempt.detected_at.desc()).limit(20).all(),
        pterodactyl_status=pts,
        port_status=port_status
    )

@app.route('/dashboard/admin')
@login_required
@admin_req
def dashboard_admin():
    if current_user.is_advanced_admin:
        return redirect(url_for('dashboard_advanced'))
    act, ip = request.args.get('action'), request.args.get('ip')
    if act == 'block' and ip:
        if is_protected_ip(ip):
            flash(f'Cannot block your own/local IP {ip}', 'warning')
        else:
            block_ip(ip, 'Manual block', current_user.username)
            flash(f'IP {ip} blocked', 'success')
    elif act == 'unblock' and ip:
        unblock_ip(ip)
        flash(f'IP {ip} unblocked', 'success')
    blk = BlockedIP.query.filter_by(is_active=True).all()
    return render_template(
        'dashboard_admin.html',
        stats=get_stats(),
        total_users=User.query.count(),
        total_blocked=len(blk),
        total_attacks=DDoSAttempt.query.count(),
        blocked_ips=blk,
        ddos_attempts=DDoSAttempt.query.order_by(DDoSAttempt.detected_at.desc()).limit(50).all()
    )

@app.route('/dashboard/advanced', methods=['GET', 'POST'])
@login_required
def dashboard_advanced():
    if not current_user.is_advanced_admin:
        if request.method == 'POST':
            if request.form.get('advanced_password') == ADVANCED_ADMIN_PASS:
                current_user.is_advanced_admin = True
                db.session.commit()
                flash('Advanced access granted!', 'success')
                return redirect(url_for('dashboard_advanced'))
            flash('Wrong password', 'danger')
        return render_template('dashboard_advanced_login.html')
    act, ip = request.args.get('action'), request.args.get('ip')
    if act == 'block' and ip:
        if is_protected_ip(ip):
            flash(f'Cannot block your own/local IP {ip}', 'warning')
        else:
            block_ip(ip, 'Advanced block', current_user.username)
            flash(f'IP {ip} blocked', 'success')
    elif act == 'unblock' and ip:
        unblock_ip(ip)
        flash(f'IP {ip} unblocked', 'success')
    blk = BlockedIP.query.filter_by(is_active=True).all()
    return render_template(
        'dashboard_advanced.html',
        stats=get_stats(),
        recent_actions=VPSAction.query.order_by(VPSAction.created_at.desc()).limit(30).all(),
        blocked_ips=blk,
        ddos_attempts=DDoSAttempt.query.order_by(DDoSAttempt.detected_at.desc()).limit(50).all()
    )

@app.route('/api/block-ip', methods=['POST'])
@login_required
@admin_req
def api_block():
    ip = request.form.get('ip', '').strip()
    if not ip:
        return jsonify({'success': False, 'error': 'No IP'})
    if is_protected_ip(ip):
        return jsonify({'success': False, 'error': 'Cannot block your own/local IP'})
    block_ip(ip, request.form.get('reason', 'Manual'), current_user.username)
    return jsonify({'success': True})

@app.route('/api/unblock-ip', methods=['POST'])
@login_required
@admin_req
def api_unblock():
    ip = request.form.get('ip', '').strip()
    if not ip:
        return jsonify({'success': False})
    unblock_ip(ip)
    return jsonify({'success': True})

@app.route('/api/vps-action', methods=['POST'])
@login_required
@adv_req
def api_vps():
    act = request.form.get('action_type')
    det = {}
    if act == 'stop_port':
        det['port'] = request.form.get('port')
    elif act == 'port_forward':
        det['source_port'] = request.form.get('source_port')
        det['dest_port'] = request.form.get('dest_port')
    return jsonify({'success': True, 'action_id': vps_action(act, det)})

@app.route('/api/action-progress/<int:aid>')
@login_required
def api_prog(aid):
    a = db.session.get(VPSAction, aid)
    return jsonify({'success': True, 'progress': a.progress, 'message': a.message, 'status': a.status}) if a else jsonify({'success': False})

@app.route('/vps-action/<int:aid>')
@login_required
@adv_req
def vps_page(aid):
    a = db.session.get(VPSAction, aid)
    if not a:
        flash('Not found', 'danger')
        return redirect(url_for('dashboard_advanced'))
    return render_template('vps_action.html', action=a)

@app.route('/admin/users')
@login_required
@admin_req
def manage_users():
    return render_template('manage_users.html', users=User.query.all())

@app.route('/admin/user/<int:uid>/action', methods=['POST'])
@login_required
@admin_req
def user_act(uid):
    u = db.session.get(User, uid)
    if not u:
        return jsonify({'success': False})
    act = request.form.get('action')
    if u.id == current_user.id and act != 'edit':
        return jsonify({'success': False})
    if act == 'delete':
        db.session.delete(u)
    elif act == 'toggle_block':
        u.is_blocked = not u.is_blocked
    elif act == 'promote_admin':
        u.is_admin = not u.is_admin
        if not u.is_admin:
            u.is_advanced_admin = False
    elif act == 'edit':
        u.username = request.form.get('username', u.username)
        u.email = request.form.get('email', u.email)
    db.session.commit()
    return jsonify({'success': True})

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        if request.form.get('action') == 'update_profile':
            current_user.username = request.form.get('username', current_user.username)
            current_user.email = request.form.get('email', current_user.email)
            db.session.commit()
            flash('Updated', 'success')
        elif request.form.get('action') == 'change_password':
            if current_user.check_password(request.form.get('current_password', '')):
                if request.form.get('new_password') == request.form.get('confirm_password'):
                    current_user.set_password(request.form.get('new_password'))
                    db.session.commit()
                    flash('Changed', 'success')
                else:
                    flash('Mismatch', 'danger')
            else:
                flash('Wrong password', 'danger')
    return render_template('profile.html', user=current_user)

@app.route('/settings', methods=['GET', 'POST'])
@login_required
@admin_req
def settings():
    # Toggle keys that use checkboxes – unchecked means "off"
    TOGGLE_KEYS = {'auto_protection', 'enable_registration', 'maintenance_mode', 'auto_block'}
    TEXT_KEYS = {'background', 'panel_name', 'ddos_threshold'}

    if request.method == 'POST':
        # Text / number fields
        for k in TEXT_KEYS:
            v = request.form.get(k)
            if v is not None:
                set_setting(k, v.strip() if isinstance(v, str) else v)
        # Checkboxes: present = on, missing = off
        for k in TOGGLE_KEYS:
            v = request.form.get(k)
            set_setting(k, 'on' if v == 'on' else 'off')
        flash('Saved!', 'success')
        return redirect(url_for('settings'))

    return render_template('settings.html', settings={
        k: get_setting(k, 'on' if k in TOGGLE_KEYS else '')
        for k in list(TOGGLE_KEYS) + list(TEXT_KEYS)
    })

@app.route('/api/stats')
@login_required
def api_stats():
    return jsonify(get_stats())

@app.errorhandler(404)
def e404(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def e500(e):
    db.session.rollback()
    return render_template('500.html'), 500

# ==================== MAIN ====================

def main():
    global ADVANCED_ADMIN_PASS
    print("\n" + "=" * 60)
    print("        NR PROTECTION - VPS SECURITY SYSTEM")
    print("        FIXED: Local IPs never blocked")
    print("        FIXED: Connections killed on block")
    print("        FIXED: Settings toggles save correctly")
    print("        (c) 2024 NR Protection")
    print("=" * 60)
    print("[OK] License: VERIFIED" if check_license() else "[!] License: NOT VERIFIED")
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE) as f:
                ADVANCED_ADMIN_PASS = json.load(f).get('advanced_admin_pass')
        except Exception:
            ADVANCED_ADMIN_PASS = None
    if not ADVANCED_ADMIN_PASS:
        # Non-interactive friendly: use env or default, still allow override
        env_pass = os.environ.get('NR_ADVANCED_PASS', '').strip()
        if env_pass:
            ADVANCED_ADMIN_PASS = env_pass
            print("[OK] Advanced password from NR_ADVANCED_PASS env")
        else:
            try:
                print("\n[!] Set Advanced Admin Password")
                ADVANCED_ADMIN_PASS = input("Enter password: ").strip()
            except (EOFError, KeyboardInterrupt):
                ADVANCED_ADMIN_PASS = "advanced"
                print("[!] No TTY – using default advanced password: advanced")
        with open(SETTINGS_FILE, 'w') as f:
            json.dump({'advanced_admin_pass': ADVANCED_ADMIN_PASS}, f)
        print("[OK] Password set!")
    with app.app_context():
        init_db()
        t = get_setting('ddos_threshold', '50')
        ab = get_setting('auto_block', 'on')
    threading.Thread(target=monitor_all_ports, daemon=True).start()
    print(f"\n[*] URL: http://0.0.0.0:3500")
    print(f"[*] Admin: admin / admin")
    print(f"[*] Advanced Pass: {'*' * len(ADVANCED_ADMIN_PASS)}")
    print(f"[*] DDoS Threshold: {t} connections")
    print(f"[*] Auto-Block: {ab}")
    print(f"[*] Monitor: ALL PORTS – own/local IPs NEVER blocked")
    print(f"[*] On block: connections killed + requests silently dropped (looks like nothing)")
    print("=" * 60 + "\n")
    app.run(host='0.0.0.0', port=3500, debug=False, threaded=True)

if __name__ == '__main__':
    main()
